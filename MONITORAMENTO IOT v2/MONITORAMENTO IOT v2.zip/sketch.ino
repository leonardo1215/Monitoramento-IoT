#include <WiFi.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "DHTesp.h"

#define DHT_PIN 15
#define LDR_PIN 34

#define LED_VERDE 25
#define LED_AMARELO 26
#define LED_VERMELHO 27
#define BUZZER_PIN 14

#define OLED_SDA 21
#define OLED_SCL 22

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

DHTesp dht;
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

const char* ssid = "Wokwi-GUEST";
const char* password = "";

const char* mqttServer = "broker.hivemq.com";
const int mqttPort = 1883;

const char* topicoDados = "leonardo/iot/monitoramento/dados";
const char* topicoComando = "leonardo/iot/monitoramento/comando";

WiFiClient espClient;
PubSubClient client(espClient);

bool buzzerSilenciado = false;

void callback(char* topic, byte* message, unsigned int length) {
  String comando = "";

  for (unsigned int i = 0; i < length; i++) {
    comando += (char)message[i];
  }

  comando.trim();

  Serial.print("Topico recebido: ");
  Serial.println(topic);
  Serial.print("Comando recebido: ");
  Serial.println(comando);

  if (String(topic) == topicoComando) {
    if (comando == "SILENCIAR") {
      buzzerSilenciado = true;
      noTone(BUZZER_PIN);
      Serial.println("Buzzer silenciado pelo Node-RED");
    }

    if (comando == "ATIVAR") {
      buzzerSilenciado = false;
      Serial.println("Buzzer ativado pelo Node-RED");
    }
  }
}

void conectarWiFi() {
  WiFi.begin(ssid, password);
  Serial.print("Conectando ao WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi conectado!");
}

void conectarMQTT() {
  while (!client.connected()) {
    Serial.print("Conectando ao MQTT... ");

    String clientId = "ESP32-Leonardo-" + String(random(0xffff), HEX);

    if (client.connect(clientId.c_str())) {
      Serial.println("conectado!");

      client.subscribe(topicoComando);
      Serial.print("Inscrito no topico: ");
      Serial.println(topicoComando);

    } else {
      Serial.print("erro, rc=");
      Serial.println(client.state());
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(LED_VERDE, OUTPUT);
  pinMode(LED_AMARELO, OUTPUT);
  pinMode(LED_VERMELHO, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  noTone(BUZZER_PIN);

  dht.setup(DHT_PIN, DHTesp::DHT22);

  Wire.begin(OLED_SDA, OLED_SCL);
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("Monitoramento IoT");
  display.println("Conectando...");
  display.display();

  conectarWiFi();

  client.setServer(mqttServer, mqttPort);
  client.setCallback(callback);
}

void loop() {
  if (!client.connected()) {
    conectarMQTT();
  }

  client.loop();

  TempAndHumidity dados = dht.getTempAndHumidity();

  float temperatura = dados.temperature;
  float umidade = dados.humidity;
  int luminosidade = analogRead(LDR_PIN);

  String status = "NORMAL";

  digitalWrite(LED_VERDE, LOW);
  digitalWrite(LED_AMARELO, LOW);
  digitalWrite(LED_VERMELHO, LOW);

  if (temperatura >= 35 || luminosidade < 1000) {
    status = "CRITICO";
    digitalWrite(LED_VERMELHO, HIGH);
  } else if (temperatura >= 30 || luminosidade < 2000) {
    status = "ATENCAO";
    digitalWrite(LED_AMARELO, HIGH);
  } else {
    status = "NORMAL";
    digitalWrite(LED_VERDE, HIGH);
    buzzerSilenciado = false;
  }

  if (status == "CRITICO" && !buzzerSilenciado) {
    tone(BUZZER_PIN, 1000);
  } else {
    noTone(BUZZER_PIN);
  }

  String estadoBuzzer;

  if (status == "CRITICO" && !buzzerSilenciado) {
    estadoBuzzer = "TOCANDO";
  } else if (buzzerSilenciado) {
    estadoBuzzer = "SILENCIADO";
  } else {
    estadoBuzzer = "DESLIGADO";
  }

  String payload = "{";
  payload += "\"temperatura\":" + String(temperatura, 1) + ",";
  payload += "\"umidade\":" + String(umidade, 1) + ",";
  payload += "\"luminosidade\":" + String(luminosidade) + ",";
  payload += "\"status\":\"" + status + "\",";
  payload += "\"buzzer\":\"" + estadoBuzzer + "\"";
  payload += "}";

  bool enviado = client.publish(topicoDados, payload.c_str());

  if (enviado) {
    Serial.println("MQTT enviado com sucesso:");
    Serial.println(payload);
  } else {
    Serial.println("ERRO ao enviar MQTT");
  }

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("Monitoramento IoT");

  display.setCursor(0, 16);
  display.print("Temp: ");
  display.print(temperatura, 1);
  display.println(" C");

  display.setCursor(0, 28);
  display.print("Umid: ");
  display.print(umidade, 1);
  display.println(" %");

  display.setCursor(0, 40);
  display.print("Luz: ");
  display.println(luminosidade);

  display.setCursor(0, 52);
  display.print("Buzz: ");
  display.println(estadoBuzzer);

  display.display();

  delay(2000);
}